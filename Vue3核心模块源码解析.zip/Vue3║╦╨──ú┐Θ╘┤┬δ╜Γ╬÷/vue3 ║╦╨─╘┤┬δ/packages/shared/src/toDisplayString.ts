export const toDisplayString = (val) => {
  return String(val);
};
